﻿<#
.SYNOPSIS
    Script de Auditoría Automática para TechStore (Taller de Programación Web - UTP)
    Verifica que el proyecto cumpla con los 5 criterios exigidos en la rúbrica oficial.

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Auditar_Cumplimiento_Rubrica.ps1 -RutaProyecto "."
#>

param (
    [Parameter(Mandatory=$false)]
    [string]$RutaProyecto = "."
)

Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host " [AUDITORIA UTP] Evaluando Requisitos de Rúbrica en TechStore" -ForegroundColor Cyan
Write-Host " Directorio: $RutaProyecto" -ForegroundColor Yellow
Write-Host "=================================================================" -ForegroundColor Cyan

if (-not (Test-Path -Path $RutaProyecto)) {
    Write-Host "[ERROR] La ruta especificada no existe: $RutaProyecto" -ForegroundColor Red
    return
}

# 1. Buscar archivos clave
$archivosHtml = Get-ChildItem -Path $RutaProyecto -Filter "*.html" -Recurse
$archivosCss  = Get-ChildItem -Path $RutaProyecto -Filter "*.css" -Recurse
$archivosJs   = Get-ChildItem -Path $RutaProyecto -Filter "*.js" -Recurse

Write-Host "Archivos encontrados:" -ForegroundColor Gray
Write-Host "  HTML: $($archivosHtml.Count) archivos" -ForegroundColor White
Write-Host "  CSS : $($archivosCss.Count) archivos" -ForegroundColor White
Write-Host "  JS  : $($archivosJs.Count) archivos" -ForegroundColor White
Write-Host "-----------------------------------------------------------------" -ForegroundColor DarkGray

$contenidoCss = ""
foreach ($f in $archivosCss) { $contenidoCss += (Get-Content $f.FullName -Raw -ErrorAction SilentlyContinue) + "`n" }

$contenidoJs = ""
foreach ($f in $archivosJs) { $contenidoJs += (Get-Content $f.FullName -Raw -ErrorAction SilentlyContinue) + "`n" }

$contenidoHtml = ""
foreach ($f in $archivosHtml) { $contenidoHtml += (Get-Content $f.FullName -Raw -ErrorAction SilentlyContinue) + "`n" }

# Verificación de Criterios
$puntaje = 0

# Criterio 1: Diseño Responsivo (Flexbox & Grid & Media Queries)
Write-Host "[Criterio 1: Diseno Responsivo y Maquetacion]" -ForegroundColor Cyan
$tieneFlex = $contenidoCss -match "display\s*:\s*flex"
$tieneGrid = $contenidoCss -match "display\s*:\s*grid"
$tieneMedia = $contenidoCss -match "@media"

if ($tieneFlex -and $tieneGrid -and $tieneMedia) {
    Write-Host "  [APROBADO] Cumple con Flexbox, CSS Grid y Media Queries (@media)." -ForegroundColor Green
    $puntaje += 4
} else {
    Write-Host "  [ATENCION] Falta verificar: Flex=$tieneFlex, Grid=$tieneGrid, MediaQueries=$tieneMedia" -ForegroundColor Yellow
}

# Criterio 2: Formularios y Tablas Estilizadas
Write-Host "[Criterio 2: Formularios y Tablas Estilizadas]" -ForegroundColor Cyan
$tieneForms = $contenidoHtml -match "<form"
$tieneTablas = $contenidoHtml -match "<table"
$tieneFocus = $contenidoCss -match ":focus|:hover"

if ($tieneForms -and $tieneTablas -and $tieneFocus) {
    Write-Host "  [APROBADO] Incluye formularios (<form>), tablas (<table) y pseudo-clases de estilo (:focus/:hover)." -ForegroundColor Green
    $puntaje += 4
} else {
    Write-Host "  [ATENCION] Verificar presencia de formularios ($tieneForms), tablas ($tieneTablas) y estilos ($tieneFocus)." -ForegroundColor Yellow
}

# Criterio 3: Animaciones y Transiciones CSS
Write-Host "[Criterio 3: Animaciones y Transiciones CSS]" -ForegroundColor Cyan
$tieneTransition = $contenidoCss -match "transition\s*:"
$tieneKeyframes  = $contenidoCss -match "@keyframes"
$tieneTransform  = $contenidoCss -match "transform\s*:"

if ($tieneTransition -and $tieneKeyframes -and $tieneTransform) {
    Write-Host "  [APROBADO] Cumple con transitions, transforms y animaciones @keyframes." -ForegroundColor Green
    $puntaje += 4
} else {
    Write-Host "  [ATENCION] Verificar animaciones: Transitions=$tieneTransition, Keyframes=$tieneKeyframes, Transforms=$tieneTransform" -ForegroundColor Yellow
}

# Criterio 4: Menu Responsivo y Ventana Modal
Write-Host "[Criterio 4: Menu Responsivo y Ventanas Modales]" -ForegroundColor Cyan
$tieneModalJs = $contenidoJs -match "modal|dialog|backdrop" -or $contenidoHtml -match "modal|dialog"
$tieneMenuJs  = $contenidoJs -match "menu|nav|toggle|hamburguesa"

if ($tieneModalJs -and $tieneMenuJs) {
    Write-Host "  [APROBADO] Detectado control de Ventana Modal y Menu Responsivo en JS/HTML." -ForegroundColor Green
    $puntaje += 4
} else {
    Write-Host "  [ATENCION] Falta verificar logica de Modal ($tieneModalJs) o Menu Responsive ($tieneMenuJs)." -ForegroundColor Yellow
}

# Criterio 5: Eventos JS y Manipulacion del DOM
Write-Host "[Criterio 5: Eventos en JavaScript y Manipulacion del DOM]" -ForegroundColor Cyan
$tieneEventos = $contenidoJs -match "addEventListener"
$tieneDom     = $contenidoJs -match "createElement|innerHTML|textContent|appendChild"
$tieneStorage = $contenidoJs -match "localStorage|sessionStorage"

if ($tieneEventos -and $tieneDom) {
    Write-Host "  [APROBADO] Cumple con addEventListener y manipulacion dinamica del DOM." -ForegroundColor Green
    if ($tieneStorage) {
        Write-Host "  [EXTRA] Incluye persistencia de datos con localStorage." -ForegroundColor Green
    }
    $puntaje += 4
} else {
    Write-Host "  [ATENCION] Verificar listeners de eventos ($tieneEventos) y manipulacion del DOM ($tieneDom)." -ForegroundColor Yellow
}

Write-Host "-----------------------------------------------------------------" -ForegroundColor DarkGray
Write-Host "PUNTAJE ESTIMADO SEGUN RUBRICA: $puntaje / 20 PUNTOS" -ForegroundColor $(if ($puntaje -ge 18) { "Green" } else { "Yellow" })
Write-Host "=================================================================" -ForegroundColor Cyan
