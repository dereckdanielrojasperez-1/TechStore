# Reglas de Revisión y Auditoría Frontend para TechStore
# Basado en estándares industriales de n8n review-rules y Cursor Prompts

Este documento compila las directrices que debe seguir cualquier desarrollador o asistente de IA al editar el código de TechStore.

---

## 1. Separación Estricta de Responsabilidades (HTML / CSS / JS)
- **Prohibido JS en línea:** Nunca uses atributos como `onclick="..."`, `onchange="..."` o `onload="..."` directamente dentro de etiquetas HTML. Todo evento debe registrarse en `js/app.js` mediante `addEventListener`.
- **Prohibido CSS en línea:** No uses atributos `style="..."` salvo para valores dinámicos calculados (ej: ancho de barra de progreso). Toda la apariencia pertenece a `css/estilos.css`.

---

## 2. Rendimiento en Animaciones CSS (60 FPS)
- **Propiedades Seguras:** Realiza transiciones y animaciones únicamente sobre `transform` y `opacity`. Estas propiedades son aceleradas por GPU y no provocan re-cálculos de diseño (*reflow* o *repaint*).
- **Evitar transiciones pesadas:** No animes propiedades como `width`, `height`, `top`, `left`, `margin` o `padding`, ya que degradan el rendimiento en dispositivos móviles.

---

## 3. Seguridad en Manipulación del DOM (Prevención XSS)
- **Regla de Oro:** Si un dato proviene del usuario (campos de texto, URL params o storage), **NUNCA** lo inyectes usando `elemento.innerHTML = variable`.
- **Alternativa Segura:** Usa `elemento.textContent = variable` o crea los nodos con `document.createElement()`, asignando atributos con `setAttribute()`.

---

## 4. Accesibilidad Web (A11y)
- Toda imagen `<img>` debe contar obligatoriamente con un atributo `alt` descriptivo.
- Todo campo `<input>` debe estar enlazado a un `<label for="id-del-input">`.
- Los botones que solo contienen iconos (como el botón hamburguesa o el carrito) deben incluir un `aria-label="Abrir carrito"` para lectores de pantalla.
- Las ventanas modales deben tener el rol `role="dialog"` y `aria-modal="true"`.

---

## 5. Almacenamiento Local Seguro (`localStorage`)
- Valida siempre los datos al leerlos con `JSON.parse()`. Envuelve la lectura en un bloque `try/catch` para evitar que datos corruptos rompan la ejecución del script.
- Limpia los datos caducados o anómalos si la estructura del catálogo cambia.
