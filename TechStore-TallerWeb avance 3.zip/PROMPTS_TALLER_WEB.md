# Banco de Prompts Especializados para TechStore (Taller Web UTP)
# Estructurados según las mejores técnicas de Prompt Engineering (Anthropic XML Delimiters)

Copia y pega cualquiera de estos prompts en tu otro chat de IA para resolver requerimientos específicos del proyecto con máxima precisión.

---

### Prompt 1: Implementar o Perfeccionar el Carrito de Compras Dinámico
```xml
<context>
Estoy desarrollando la tienda e-commerce TechStore para el curso Taller de Programación Web.
Tengo index.html, css/estilos.css, js/app.js y js/datos.js.
</context>

<instructions>
Ayúdame a implementar la funcionalidad completa del Carrito de Compras en JavaScript Vanilla (ES6+):
1. Al hacer clic en "Añadir al Carrito" en cualquier tarjeta de producto, debe capturar el ID y agregarlo al arreglo de compras.
2. Debe actualizar el contador numérico (badge) ubicado en el icono del carrito en la barra de navegación superior.
3. Si el producto ya existe en el carrito, debe incrementar la cantidad en vez de duplicar la fila.
4. Debe persistir los datos en localStorage para que no se borren al recargar la página.
5. Debe calcular el subtotal, el IGV (18%) y el total a pagar.
6. Cumple con Clean Code y no uses librerías externas ni onclick en el HTML.
</instructions>

<format>
Entrega únicamente el código JavaScript necesario para js/app.js y las clases CSS complementarias para css/estilos.css.
</format>
```

---

### Prompt 2: Crear la Ventana Modal Flotante (Vista Rápida de Producto)
```xml
<context>
La rúbrica del proyecto exige expresamente: "Creación de un menú de navegación adaptable y ventanas modales o flotantes utilizando HTML, CSS y JavaScript".
</context>

<instructions>
Genera una ventana modal emergente para TechStore que cumpla los siguientes requisitos:
1. Al hacer clic en el botón "Vista Rápida" de un producto, se debe abrir un modal centrado en pantalla sobre un fondo oscuro semitransparente (backdrop).
2. El modal debe mostrar: foto ampliada, título, categoría, precio anterior, precio actual con descuento, stock disponible y botón "Añadir al carrito".
3. El modal debe poder cerrarse de 3 formas:
   - Haciendo clic en el botón con la "X" en la esquina superior derecha.
   - Haciendo clic fuera del contenido del modal (en el backdrop).
   - Presionando la tecla 'Escape' en el teclado.
4. Debe incluir animación CSS suave de apertura (fade-in y scale).
</instructions>

<format>
Entrega:
1. El bloque HTML del modal para colocar al final del body.
2. Los estilos CSS con animaciones keyframes para css/estilos.css.
3. Las funciones abrirModal() y cerrarModal() para js/app.js.
</format>
```

---

### Prompt 3: Validación de Formularios en Tiempo Real (Contacto / Login)
```xml
<context>
Necesito validar el formulario de contacto.html y login.html de TechStore según la rúbrica de Formularios Estilizados y Manipulación del DOM.
</context>

<instructions>
Crea una validación robusta y accesible en JavaScript:
1. Validar nombre: no vacío, mínimo 3 caracteres, solo letras y espacios.
2. Validar email: formato válido mediante expresión regular.
3. Validar teléfono: formato de celular peruano (debe empezar con 9 y contener exactamente 9 dígitos numéricos).
4. Validar mensaje: mínimo 10 caracteres.
5. La validación debe activarse en el evento 'input' o 'blur' de cada campo, mostrando un mensaje de error estilizado debajo y cambiando el borde a rojo o verde si es válido.
6. En el evento 'submit', si hay errores, debe prevenir el envío (event.preventDefault()) y enfocar el primer campo inválido.
</instructions>
```

---

### Prompt 4: Redacción del Informe Técnico Final en PDF
```xml
<context>
Debo entregar el Informe Final del Proyecto en PDF según la estructura de la rúbrica UTP de Taller de Programación Web.
El proyecto se llama TechStore (E-commerce de productos tecnológicos).
</context>

<instructions>
Redacta el informe técnico completo incluyendo:
1. Carátula institucional formal UTP.
2. Introducción y Planteamiento del Problema.
3. Objetivos Generales y Específicos.
4. Marco Teórico detallado (HTML5 Semántico, CSS Grid vs Flexbox, Animaciones CSS3, Eventos en JS, Manipulación del DOM y LocalStorage).
5. Implementación de la Solución (Estructura de archivos, arquitectura de estilos, módulos HTML y lógica de app.js).
6. Resultados y Descripción de Pruebas Funcionales.
7. Conclusiones y Recomendaciones de escalabilidad.
8. Bibliografía en formato APA.
</instructions>
```
