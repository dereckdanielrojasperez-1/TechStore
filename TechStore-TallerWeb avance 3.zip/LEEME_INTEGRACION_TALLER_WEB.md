# Guía de Integración Completa para TechStore (Taller de Programación Web)

Este paquete ZIP contiene todos los recursos especializados, prompts de sistema, guías de ciberseguridad OWASP, manuales de Clean Code y scripts de auditoría necesarios para integrar y finalizar el proyecto **TechStore** con la máxima nota (20/20).

---

## 📦 Contenido del Paquete

1. **`.cursorrules`**: Reglas de IA de nivel senior optimizadas para el stack del proyecto (HTML5 semántico, CSS3 Flexbox/Grid, animaciones y Vanilla JS). Al colocarlo en la raíz, cualquier IA en Cursor o VS Code respetará la arquitectura sin usar librerías externas.
2. **`SKILL.md`**: Documento de habilidad formal para asistentes de IA. Contiene el mapa de archivos, convenciones de nombres, funciones clave de `app.js` y la rúbrica oficial UTP.
3. **`Clean_Code_JavaScript_Guia.md`**: Manual completo de buenas prácticas para JavaScript (funciones de única responsabilidad, nombres descriptivos, prevención de código espagueti).
4. **Hojas de Seguridad OWASP (Frontend Web)**:
   - `Cross_Site_Scripting_Prevention_Cheat_Sheet.md`: Mitigación de XSS en aplicaciones web.
   - `DOM_based_XSS_Prevention_Cheat_Sheet.md`: Prevención de vulnerabilidades al manipular el DOM dinámicamente.
   - `Input_Validation_Cheat_Sheet.md`: Validación de datos en formularios del lado del cliente.
   - `HTML5_Security_Cheat_Sheet.md`: Directrices de seguridad en HTML5 y almacenamiento local.
5. **`Frontend_Review_Rules.md`**: Reglas de revisión de código (60 FPS en animaciones, accesibilidad A11y, prohibición de eventos inline `onclick`).
6. **`PROMPTS_TALLER_WEB.md`**: Banco de prompts estructurados con etiquetas XML listos para copiar y pedirle a la IA:
   - Crear el carrito de compras con persistencia (`localStorage`).
   - Crear la ventana modal flotante accesible para vista rápida.
   - Crear validaciones de formularios en tiempo real.
   - Redactar el informe técnico final en formato Word/PDF según la rúbrica.
7. **`Auditar_Cumplimiento_Rubrica.ps1`**: Script ejecutable en PowerShell que analiza tus archivos HTML, CSS y JS, evalúa los 5 criterios de la rúbrica UTP y calcula tu puntaje sobre 20.

---

## 🚀 Pasos de Integración en tu Proyecto

### Paso 1: Descomprimir en la raíz
Copia este archivo ZIP o extrae su contenido directamente dentro de la carpeta principal de tu proyecto:  
`C:\Users\Computecno\Documents\Taller Web Trabajo\TechStore-TallerWeb avance 3\TechStore-TallerWeb`  
*(o en tu carpeta de trabajo `TechStore`)*.

Los archivos `.cursorrules`, `SKILL.md` y demás guías deben quedar al mismo nivel que `index.html`.

### Paso 2: Activar la asistencia con tu otro chat de IA
Abre tu chat de IA y envíale este mensaje:
> *"He integrado el paquete de recursos en la raíz de mi proyecto TechStore. Escanea los archivos `SKILL.md` y `.cursorrules`. Adopta el rol de Ingeniero Frontend y Evaluador de Taller de Programación Web. Ayúdame con la siguiente tarea: [escribes lo que deseas hacer, ej: revisar el carrito o redactar el informe técnico]"*

### Paso 3: Ejecutar la Auditoría Automática
En cualquier momento puedes abrir PowerShell en la carpeta del proyecto y ejecutar:
```powershell
powershell -ExecutionPolicy Bypass -File .\Auditar_Cumplimiento_Rubrica.ps1
```
El script te confirmará si cumples al 100% con Flexbox, CSS Grid, transiciones, animaciones, modales, menú responsive y persistencia en el DOM.
